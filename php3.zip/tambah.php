<h3>Form Tambah Mahasiswa</h3>

<form method="post" action="index.php">

Nama: <input  name="nama" type="text" value=""> 
<br>
Jenis Kelamin: <select name="jeniskelamin">
					<option value=1>Laki-laki</option>
					<option value=2>Perempuan</option>
				</select>
<br>
Longitude:<input  name="longitude" type="text" value=""> 
<br>
Latitude:<input  name="latitude" type="text" value=""> 
<br>

<button href="index.php">Batal</button>
<input name="simpan" type="submit" value="Simpan">

</form>