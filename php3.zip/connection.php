<?php

$hostname     = "localhost"; // Masukan nama host
$username     = "root";      // Masukan user database
$password     = "";          //Masukan Password
$databasename = "latihan";// Masukan nama database
// Membuat koneksi
$connection = mysqli_connect($hostname, $username, $password,$databasename);
// Cek koneksi
if (!$connection) {
    die("Unable to Connect database: " . mysqli_connect_error());
}


?>